bool more(int x, int y) { return x > y; } // for descending order
bool less(int x, int y) { return x < y; } // for ascending order